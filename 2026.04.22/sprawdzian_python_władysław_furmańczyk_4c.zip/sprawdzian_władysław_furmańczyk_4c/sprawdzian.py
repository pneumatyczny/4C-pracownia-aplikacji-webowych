__copyright__ = "Zespół szkół komunikacji"
__author__ = "Władysław Furmańczyk 4C"
import datetime
import json

from models.Student import Student
from models.Teacher import Teacher
from models.Subject import Subject
from models.Grades import Grades
from year_grade import year_grade

teachers = []
subjects = []
students = []
grades = []


def load_teachers():
    global teachers

    with open("teachers.txt", "r", encoding="utf-8") as f:
        for line in f:
            _id, name, surname = line.strip().split()
            teachers.append(Teacher(int(_id), name, surname))


def load_subjects():
    global subjects

    with open("subjects.txt", "r", encoding="utf-8") as f:
        for line in f:
            _id, name, teacher_id = line.strip().split()

            teacher = next((t for t in teachers if t._id == int(teacher_id)), None)

            if teacher:
                subjects.append(Subject(int(_id), name, teacher))


def load_students():
    global students

    with open("students.txt", "r", encoding="utf-8") as f:
        for line in f:
            _id, name, surname, birth = line.strip().split()

            birthdate = datetime.datetime.strptime(birth, "%Y-%m-%d").date()

            students.append(Student(int(_id), name, surname, birthdate))


def load_grades():
    global grades

    with open("grades.txt", "r", encoding="utf-8") as f:
        for line in f:
            parts = line.strip().split()
            student_id = int(parts[0])
            subject_id = int(parts[1])
            values = list(map(int, parts[2].split(",")))

            student = next((s for s in students if s._id == student_id), None)
            subject = next((s for s in subjects if s._id == subject_id), None)

            if not student or not subject:
                continue

            g = Grades(student, subject)

            for v in values:
                g.add_grade(v)

            grades.append(g)


def print_students():
    print("Oceny i średnie poszczególnych uczniów\n")

    for student in students:
        print(student)

        student_grades = [g for g in grades if g.student == student]

        for g in student_grades:
            avg = g.get_average()
            final = year_grade(avg)

            print(f" {g.subject.name}:")
            print(f"  Oceny: {', '.join(map(str, g.get_grades()))}")
            print(f"  Średnia: {avg:.2f}")
            print(f"  Ocena końcowa: {final}")

        print()


def export_students():
    data = []

    for student in students:
        entry = {str(student): {}}

        student_grades = [g for g in grades if g.student == student]

        for g in student_grades:
            entry[str(student)][g.subject.name] = {
                "Oceny": ", ".join(map(str, g.get_grades())),
                "Srednia": round(g.get_average(), 2),
                "Ocena roczna": year_grade(g.get_average()),
            }

        data.append(entry)

    with open("students.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def print_subjects():
    print("=" * 50)
    print()

    for subject in subjects:
        print(subject.name)
        print(f"Nauczyciel: {subject.teacher}")

        subject_grades = [g for g in grades if g.subject == subject]

        all_grades = []
        for g in subject_grades:
            all_grades.extend(g.get_grades())

        print(f"Oceny: {', '.join(map(str, all_grades))}")
        print(f"Średnia: {sum(all_grades)/len(all_grades):.2f}")
        print()


def export_subjects():
    import json

    data = []

    for subject in subjects:
        subject_grades = [g for g in grades if g.subject == subject]

        all_grades = []
        for g in subject_grades:
            all_grades.extend(g.get_grades())

        if not all_grades:
            continue

        entry = {
            subject.name: {
                "Nauczyciel": str(subject.teacher),
                "Oceny": all_grades,
                "Srednia": round(sum(all_grades) / len(all_grades), 2),
            }
        }

        data.append(entry)

    with open("subjects.json", "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4, ensure_ascii=False)


def main():
    load_teachers()
    load_subjects()
    load_students()
    load_grades()

    print_students()
    export_students()

    print_subjects()
    export_subjects()


if __name__ == "__main__":
    main()
