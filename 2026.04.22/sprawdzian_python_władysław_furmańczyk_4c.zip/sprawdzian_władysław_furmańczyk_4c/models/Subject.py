__copyright__ = "Zespół szkół komunikacji"
__author__ = "Władysław Furmańczyk 4C"


class Subject:
    def __init__(self, _id: int, name: str, teacher):
        self._id = _id
        self.name = name
        self.teacher = teacher

    def __str__(self) -> str:
        return f"{self.name} {self.teacher}"
