__copyright__ = "Zespół szkół komunikacji"
__author__ = "Władysław Furmańczyk 4C"


class Teacher:
    def __init__(self, _id: int, name: str, surname: str):
        self._id = _id
        self.name = name
        self.surname = surname

    def __str__(self) -> str:
        return f"{self.name} {self.surname}"
